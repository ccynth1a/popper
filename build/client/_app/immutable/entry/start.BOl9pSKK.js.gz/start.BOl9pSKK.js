import{a as t}from"../chunks/entry.Dq081sFG.js";export{t as start};
